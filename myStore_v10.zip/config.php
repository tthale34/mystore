<?php
/** The name of the database*/
define( 'DB_NAME', 'ttt' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );
/** Web hostname */
define( 'WEB_HOST', 'http://'.$_SERVER['HTTP_HOST']);