<?php  require 'config.php';
  require 'DB.php';
  session_start();
  $_SESSION['demo_cart'][0] = new ArrayObject(["name","id","price"]);?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>MyStore</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.min.css" rel="stylesheet">
  <style type="text/css">
html,
body,
header,
.carousel {
  height: 60vh;
}
@media (max-width: 740px) {

  html,
  body,
  header,
  .carousel {
      height: 100vh;
  }
}

@media (min-width: 800px) and (max-width: 850px) {

  html,
  body,
  header,
  .carousel {
      height: 100vh;
  }
}
.shadow {
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
}
.action-button
{	
  padding: 5px 5px;
  float: left;
  border-radius: 10px;
  font-family: 'Pacifico', cursive;
  font-size: 15px;
  color: #FFF;
  text-decoration: none;
  margin-left:1%;
}
.action-button:active
{
  transform: translate(0px,5px);
  -webkit-transform: translate(0px,5px);
  border-bottom: 1px solid;
}
.blue
{
  background-color: #3498DB;
  border-bottom: 5px solid #2980B9;
  text-shadow: 0px -2px #2980B9;
}
.red
{
  background-color: #3498DB;
  border-bottom: 5px solid #2980B9;
  //text-shadow: 0px -2px red;
}
.animate
{
  transition: all 0.1s;
  -webkit-transition: all 0.1s;
}

  </style>
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-light white scrolling-navbar">
    <div class="container">
      <!-- Brand -->
      <a class="navbar-brand waves-effect" href="<?php echo WEB_HOST;?>">
        <strong class="blue-text">MyStore</strong>
      </a>
      <!-- Collapse -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- Links -->
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <!-- Left -->
        <ul class="navbar-nav mr-auto">
            <li class="nav-item <?php if (!isset($_GET['action'])){echo 'active';} ?>">
            <a class="nav-link waves-effect" href="<?php echo(WEB_HOST);?>">Home
              <span class="sr-only">(current)</span>
            </a>
           </li>
          <li class="nav-item <?php if (isset($_GET['action']) && $_GET['action'] === 'about') {echo 'active';}?>">
            <a class="nav-link waves-effect" href="<?php echo(WEB_HOST.'/?action=about');?>">About Us</a>
          </li>
          <li class="nav-item <?php if (isset($_GET['action']) && $_GET['action'] === 'contact') {echo 'active';}?>">
            <a class="nav-link waves-effect" href="<?php echo(WEB_HOST.'/?action=contact');?>">Contact Us</a>
          </li>
        </ul>
        <!-- Right -->
        <ul class="navbar-nav nav-flex-icons">
          <li class="nav-item">
            <a class="nav-link waves-effect" href="./?action=checkout">
                <span class="badge black z-depth-1 mr-1 cart_num"><?php echo count($_SESSION['demo_cart'])-1;?></span>
              <i class="fas fa-shopping-cart"></i>
              <span class="clearfix d-none d-sm-inline-block"> Cart </span>
            </a>
          </li>
          <li class="nav-item">
            <a href="https://www.facebook.com/tthale34" class="nav-link waves-effect" target="_blank">
              <i class="fab fa-facebook-f"></i>
            </a>
          </li>
          <li class="nav-item">
            <a href="https://twitter.com/tebogothale" class="nav-link waves-effect" target="_blank">
              <i class="fab fa-twitter"></i>
            </a>
          </li>
          <li class="nav-item">
              <?php if(isset($_SESSION['ID'])){
                  echo '<a class="action-button shadow animate blue" href="./login_handler.php/?action=logout" role="button">Logout</a>';
              }else {
                  echo '<a class="action-button shadow animate blue" href="/?action=login" role="button">Login/Register</a>';
              }?>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Navbar -->
  <!--Carousel Wrapper-->
  <div id="carousel-example-1z" class="carousel slide carousel-fade pt-4" data-ride="carousel">
    <!--Indicators-->
    <ol class="carousel-indicators">
      <li data-target="#carousel-example-1z" data-slide-to="0" class="active"></li>
      <li data-target="#carousel-example-1z" data-slide-to="1"></li>
      <li data-target="#carousel-example-1z" data-slide-to="2"></li>
      <li data-target="#carousel-example-1z" data-slide-to="3"></li>
    </ol>
    <!--/.Indicators-->
    <!--Slides-->
    <div class="carousel-inner" role="listbox">
      <!--First slide-->
      <div class="carousel-item active">
        <div class="view" style="background-image: url('img/php.jpg'); background-repeat: no-repeat; background-size: cover;">
          <!-- Mask & flexbox options-->
          <div class="mask rgba-black-strong d-flex justify-content-center align-items-center">
            <!-- Content -->
                <div class="text-center white-text mx-5 wow fadeIn">
                    <div id="chg_back_grnd" style="z-index:999;position: absolute top;">
                        <form>
                            <input data-class="btn-primary" data-input="false" data-class-icon="icon-plus" data-button-text="text" type="file" placeholder="asd" title="asd" value="asd" alt="asd">
                        </form>
                      </div>
              <p class="mb-4">
              <strong>Welcome to our free online shopping store, including features such as: Link images to an item, remove and add products on the go, link products to 3rd party applications automatically, change website layout and themes at a clicl of a button, And many more.</strong>
              </p>
              <p>
                <strong>Upload List of products to display in shopping list.</strong>
                <strong>Only excel (i.e: .xlsx, .xls, .csv) format files are permitted. You may download sample excel file <a href="<?php echo(WEB_HOST);?>/uploads/Item_list.xlsx" target="_blank">here.</a></strong>
              </p>
              <form class="post_file_upload" action="process_upload.php" method="post" enctype="multipart/form-data">
                  <input class="btn btn-outline-blue btn-lg" name="submit" type="submit" value="Upload list">
                  <i class="fas fa-graduation-cap ml-2"></i>                
                  <input type="file" name="file" required>
              </form>
            </div>
            <!-- Content -->
          </div>
          <!-- Mask & flexbox options-->
        </div>
      </div>
      <!--/First slide-->
      <!--Second slide-->
      <div class="carousel-item">
        <div class="view" style="background-image: url('img/jquery.jpg'); background-repeat: no-repeat; background-size: cover;n">
          <!-- Mask & flexbox options-->
          <div class="mask rgba-black-strong d-flex justify-content-center align-items-center">
            <!-- Content -->
            <div class="text-center white-text mx-5 wow fadeIn">
            <p class="mb-4">
            <strong>Welcome to our free online shopping store, including features such as: Link images to an item, remove and add products on the go, link products to 3rd party applications automatically, change website layout and themes at a clicl of a button, And many more.</strong>
              </p>
              <p>
                <strong>Upload List of products to display in shopping list.</strong>
                <strong>Only excel (i.e: .xlsx, .xls, .csv) format files are permitted. You may download sample excel file <a href="<?php echo(WEB_HOST);?>/uploads/Item_list.xlsx" target="_blank">here.</a></strong>
              </p>
              <form class="post_file_upload" action="process_upload.php" method="post" enctype="multipart/form-data">
                  <input class="btn btn-outline-blue btn-lg" name="submit" type="submit" value="Upload list">
                  <i class="fas fa-graduation-cap ml-2"></i>                
                  <input type="file" name="file" required>
              </form>
            </div>
            <!-- Content -->
          </div>
          <!-- Mask & flexbox options-->
        </div>
      </div>
      <!--/Second slide-->
      <!--Third slide-->
      <div class="carousel-item">
        <div class="view" style="background-image: url('img/tdd.jpg'); background-repeat: no-repeat; background-size: cover;">

          <!-- Mask & flexbox options-->
          <div class="mask rgba-black-strong d-flex justify-content-center align-items-center">
            <!-- Content -->
            <div class="text-center white-text mx-5 wow fadeIn">
            <p class="mb-4">
            <strong>Welcome to our free online shopping store, including features such as: Link images to an item, remove and add products on the go, link products to 3rd party applications automatically, change website layout and themes at a clicl of a button, And many more.</strong>
              </p>
              <p>
                <strong>Upload List of products to display in shopping list.</strong>
                <strong>Only excel (i.e: .xlsx, .xls, .csv) format files are permitted. You may download sample excel file <a href="<?php echo(WEB_HOST);?>/uploads/Item_list.xlsx" target="_blank">here.</a></strong>
              </p>
              <form class="post_file_upload" action="process_upload.php" method="post" enctype="multipart/form-data">
                  <input class="btn btn-outline-blue btn-lg" name="submit" type="submit" value="Upload list">
                  <i class="fas fa-graduation-cap ml-2"></i>                
                  <input type="file" name="file" required>
              </form>
            </div>
            <!-- Content -->
          </div>
          <!-- Mask & flexbox options-->
        </div>
      </div>
      <!--/Third slide-->
	    <!--Forth slide-->
      <div class="carousel-item">
        <div class="view" style="background-image: url('img/react.png'); background-repeat: no-repeat; background-size: cover;">

          <!-- Mask & flexbox options-->
          <div class="mask rgba-black-strong d-flex justify-content-center align-items-center">
            <!-- Content -->
            <div class="text-center white-text mx-5 wow fadeIn">
            <p class="mb-4">
            <strong>Welcome to our free online shopping store, including features such as: Link images to an item, remove and add products on the go, link products to 3rd party applications automatically, change website layout and themes at a clicl of a button, And many more.</strong>
              </p>
              <p>
                <strong>Upload List of products to display in shopping list.</strong>
                <strong>Only excel (i.e: .xlsx, .xls, .csv) format files are permitted. You may download sample excel file <a href="<?php echo(WEB_HOST);?>/uploads/Item_list.xlsx" target="_blank">here.</a></strong>
              </p>
              <form class="post_file_upload" action="process_upload.php" method="post" enctype="multipart/form-data">
                  <input class="btn btn-outline-blue btn-lg" name="submit" type="submit" value="Upload list">
                  <i class="fas fa-graduation-cap ml-2"></i>                
                  <input type="file" name="file" required>
              </form>
              </div>
            <!-- Content -->
          </div>
          <!-- Mask & flexbox options-->
        </div>
      </div>
      <!--/Forth slide-->
    </div>
    <!--/.Slides-->
    <!--Controls-->
    <a class="carousel-control-prev" href="#carousel-example-1z" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carousel-example-1z" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
    <!--/.Controls-->
  </div>
  <!--/.Carousel Wrapper-->
  <!--Main layout-->
  <main>
    <div class="container">
      <!--Navbar-->
      <nav class="navbar navbar-expand-lg navbar-dark mdb-color lighten-3 mt-3 mb-5">
        <!-- Navbar brand -->
        <span class="navbar-brand">Items:</span>
        <!-- Collapse button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
          aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Collapsible content -->
        <div class="collapse navbar-collapse" id="basicExampleNav">
          <!-- Links
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">All
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Shirts</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Sport wears</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Outwears</a>
            </li>
          </ul>
          <-- Links -->
          <form class="form-inline" method="post" action="">
            <div class="md-form my-0">
                <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search" name="search">
                <!--<a href="javascript:doClick();" class="BrowseFile Button">File Browsing</a><input type="file" name="files[]" id="fileElem" multiple="multiple" accept="image/*" style="" onchange="handleFiles(this.files);">-->
            </div>
          </form>
        </div>
        <!-- Collapsible content -->
      </nav>
      <!--/.Navbar-->
      <?php if(isset($_GET['action']) && $_GET['action'] === "login"):?>
        <h4><strong><a class="dark-grey-text">Login Type:</a></strong><select id="loginType" onchange="loginType()">
                              <option>Login</option>
                              <option>Register</option>
              </select></h4>
      <form class="form-inline" method="post" action="./login_handler.php">
          <div class="md-form my-0 login card custom_card">
                  <a class="blue-text"><strong>Username: </strong><input type="text" name="username" value="" required></a>
                  <a class="blue-text"><strong>Password: </strong><input type="password" name="password" value="" required></a><br><br>
                  <input type="submit" name="submit" class="btn btn-outline-blue btn-lg" value="Login">
                  <input type="reset" name="clear" class="btn btn-outline-blue btn-lg" value="Clear">
              </div></form>
      <form class="form-inline" method="post" action="./login_handler.php">
          <div class="md-form my-0 register card custom_card">
                  <a class="blue-text"><strong>Name: </strong><input type="text" name="name" value="" required></a><br>
                  <a class="blue-text"><strong>Surname: </strong><input type="text" name="surname" value=""></a><br>
                  <a class="blue-text"><strong>Brand Name: </strong><input type="text" name="brand_name" value="" required></a><br>
                  <a class="blue-text"><strong>Email Address: </strong><input type="text" name="email_address" value="" required></a><br>
                  <a class="blue-text"><strong>Password: </strong><input type="password" name="password" value="" onchange="checkPassword()" id="password" required></a><br>
                  <h2><a class="red-text" id="valid_password" style="display:none">Password criteria: 1 upper case, 1 lower case, 1 numeric digit, & 1 character.</a></h2>
                  <a class="blue-text"><strong>Confirm Password: </strong><input type="password" name="conf_password" value="" onchange="confirmPassword()" id="conf_password" required></a><br>
                  <h2><a class="red-text" id="confirm_password" style="display:none">Passwords do not match.</a></h2>
                  <a class="blue-text"><strong>Client: <select name="client_type">
                                  <option></option>
                                  <option>Consumer</option>
                                  <option>Product Provider</option>
                          </select></strong></a><br><br>
                          <input type="submit" name="submit" class="btn btn-outline-blue btn-lg" value="Register" onclick="checkPasswordMatch()">
                  <input type="reset" name="clear" class="btn btn-outline-blue btn-lg" value="Clear"><br>
              </div>
          </form>
      <?php elseif(isset($_GET['action']) && $_GET['action'] === "viewItem"):?>

<div class="container dark-grey-text mt-5">
<!--Grid row-->
<div class="row wow fadeIn">
  <!--Grid column-->
  <div class="col-md-6 mb-4">
  <?php $connection = DB::connectDB();
        $results = DB::getItem($connection,$_GET['id']);
        $row = $results->fetch_assoc();?>
    <img src="<?php print_r($row['item_image_src']);?>" class="img-fluid" alt="edit">
  </div>
  <!--Grid column-->
  <!--Grid column-->
  <div class="col-md-6 mb-4">
    <!--Content-->
    <p class="lead">
        <span><strong><?php print_r($row['item_name']);?></strong></span>
      </p>
    <div class="p-4">
      <!-- <div class="mb-3">
        <a href="">
          <span class="badge purple mr-1">Category 2</span>
        </a>
        <a href="">
          <span class="badge blue mr-1">New</span>
        </a>
        <a href="">
          <span class="badge red mr-1">Bestseller</span>
        </a>
      </div> -->
      <p class="lead">
        <span>R<?php print_r($row['item_price']);?></span>
      </p>
      <p class="lead font-weight-bold">Description</p>
      <p><?php print_r($row['item_desc']);?></p>
      <form class="d-flex justify-content-left">
        <!-- Default input -->
        <input type="number" value="1" aria-label="Search" class="form-control" style="width: 100px" id="number_items">
        <button class="btn btn-primary btn-md my-0 p" type="submit" onclick="addToCartMulti(<?php echo $row['id'];?>)">Add to cart
          <i class="fas fa-shopping-cart ml-1"></i>
        </button>
      </form>
    </div>
    <!--Content-->
  </div>
  <!--Grid column-->
</div>
<!--Grid row-->
<hr>
<!--Grid row-->
<div class="row d-flex justify-content-center wow fadeIn">
  <!--Grid column-->
  <div class="col-md-6 text-center">
    <h4 class="my-4 h4">Additional information</h4>
    <p></p>
  </div>
  <!--Grid column-->
</div>
<!--Grid row-->
<!--Grid row-->
<div class="row wow fadeIn">
  <!--Grid column-->
  <div class="col-lg-4 col-md-12 mb-4">
    <img src="" class="img-fluid" alt="asd">
  </div>
  <!--Grid column-->
  <!--Grid column-->
  <div class="col-lg-4 col-md-6 mb-4">
    <img src="" class="img-fluid" alt="qwe">
  </div>
  <!--Grid column-->
  <!--Grid column-->
  <div class="col-lg-4 col-md-6 mb-4">
    <img src="" class="img-fluid" alt="qwe">
  </div>
  <!--Grid column-->
</div>
<!--Grid row-->
</div>
      <?php elseif(isset($_GET['action']) && $_GET['action'] === "checkout"):?>
      <div class="container wow fadeIn">
      <!-- Heading -->
      <h2 class="my-5 h2 text-center">Checkout form</h2>
      <!--Grid row-->
      <div class="row">
        <!--Grid column-->
        <div class="col-md-8 mb-4">
          <!--Card-->
          <div class="card">
            <!--Card content-->
            <form class="card-body">
              <!--Grid row-->
              <div class="row">
                <!--Grid column-->
                <div class="col-md-6 mb-2">
                  <!--firstName-->
                  <div class="md-form ">
                    <input type="text" id="firstName" class="form-control" required>
                    <label for="firstName" class="">First name</label>
                  </div>
                </div>
                <!--Grid column-->
                <!--Grid column-->
                <div class="col-md-6 mb-2">
                  <!--lastName-->
                  <div class="md-form">
                    <input type="text" id="lastName" class="form-control" required>
                    <label for="lastName" class="">Last name</label>
                  </div>
                </div>
                <!--Grid column-->
              </div>
              <!--Grid row-->
              <!--Username-->
              <div class="md-form input-group pl-0 mb-5">
                <div class="input-group-prepend">
                  <span class="input-group-text" id="basic-addon1">@</span>
                </div>
                <input type="text" class="form-control py-0" placeholder="Username" aria-describedby="basic-addon1">
              </div>
              <!--email-->
              <div class="md-form mb-5">
                <input type="text" id="email" class="form-control" placeholder="youremail@example.com">
                <label for="email" class="">Email (optional)</label>
              </div>
              <!--address-->
              <div class="md-form mb-5">
                <input type="text" id="address" class="form-control" placeholder="1234 Main St" required>
                <label for="address" class="">Address</label>
              </div>
              <!--address-2-->
              <div class="md-form mb-5">
                <input type="text" id="address-2" class="form-control" placeholder="Apartment or suite">
                <label for="address-2" class="">Address 2 (optional)</label>
              </div>
              <!--Grid row-->
              <div class="row">
                <!--Grid column-->
                <div class="col-lg-4 col-md-12 mb-4">
                  <label for="country">Country</label>
                  <select class="custom-select d-block w-100" id="country" required>
                    <option value="">Choose...</option>
                    <option>South Africa</option>
                  </select>
                  <div class="invalid-feedback">
                    Please select a valid country.
                  </div>
                </div>
                <!--Grid column-->
                <!--Grid column-->
                <div class="col-lg-4 col-md-6 mb-4">
                  <label for="state">Province</label>
                  <select class="custom-select d-block w-100" id="province" required>
                    <option value="">Choose...</option>
                    <option>Gauteng</option>
                  </select>
                  <div class="invalid-feedback">
                    Please provide a valid state.
                  </div>
                </div>
                <!--Grid column-->
                <!--Grid column-->
                <div class="col-lg-4 col-md-6 mb-4">
                  <label for="zip">Zip</label>
                  <input type="text" class="form-control" id="zip" placeholder="" required>
                  <div class="invalid-feedback">
                    Zip code required.
                  </div>
                </div>
                <!--Grid column-->
              </div>
              <!--Grid row-->
              <hr>
              <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="same-address">
                <label class="custom-control-label" for="same-address">Shipping address is the same as my billing address</label>
              </div>
              <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="save-info">
                <label class="custom-control-label" for="save-info">Save this information for next time</label>
              </div>
              <hr>
              <!-- payment method -->
              <div class="d-block my-3">
                <div class="custom-control custom-radio">
                  <input id="credit" name="paymentMethod" type="radio" class="custom-control-input" checked required>
                  <label class="custom-control-label" for="credit">Credit card</label>
                </div>
                <div class="custom-control custom-radio">
                  <input id="debit" name="paymentMethod" type="radio" class="custom-control-input" required>
                  <label class="custom-control-label" for="debit">Debit card</label>
                </div>
                <div class="custom-control custom-radio">
                  <input id="paypal" name="paymentMethod" type="radio" class="custom-control-input" required>
                  <label class="custom-control-label" for="paypal">Paypal</label>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label for="cc-name">Name on card</label>
                  <input type="text" class="form-control" id="cc-name" placeholder="" required>
                  <small class="text-muted">Full name as displayed on card</small>
                  <div class="invalid-feedback">
                    Name on card is required
                  </div>
                </div>
                <div class="col-md-6 mb-3">
                  <label for="cc-number">Credit card number</label>
                  <input type="text" class="form-control" id="cc-number" placeholder="" required>
                  <div class="invalid-feedback">
                    Credit card number is required
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-3 mb-3">
                  <label for="cc-expiration">Expiration</label>
                  <input type="text" class="form-control" id="cc-expiration" placeholder="" required>
                  <div class="invalid-feedback">
                    Expiration date required
                  </div>
                </div>
                <div class="col-md-3 mb-3">
                  <label for="cc-expiration">CVV</label>
                  <input type="text" class="form-control" id="cc-cvv" placeholder="" required>
                  <div class="invalid-feedback">
                    Security code required
                  </div>
                </div>
              </div>
              <hr class="mb-4">
              <button class="btn btn-primary btn-lg btn-block" type="submit" onclick="checkOutCart()">Continue to checkout</button>
            </form>
          </div>
          <!--/.Card-->
        </div>
        <!--Grid column-->
        <!--Grid column-->
        <div class="col-md-4 mb-4">
          <!-- Heading -->
          <h4 class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-muted">Your cart</span>
            <span class="badge badge-secondary badge-pill"><?php print_r(count($_SESSION['demo_cart'])-1);?></span>
          </h4>
          <!-- Cart -->
          <ul class="list-group mb-3 z-depth-1">
              <?php $total_value = 0;?>
              <?php for($i = 1; $i <= count($_SESSION['demo_cart']); $i++):?>
            <li class="list-group-item d-flex justify-content-between lh-condensed">
              <div><?php if(isset($_SESSION['demo_cart'][$i])):?>
                  <h6 class="my-0"><?php print_r($_SESSION['demo_cart'][$i][0]);?></h6>
                <small class="text-muted"><?php print_r($_SESSION['demo_cart'][$i][1]);?></small>
                <input type="hidden" id="cart" value="cart[<?php print_r($i)?>]">
              </div>
              <span class="text-muted">R<?php print_r($_SESSION['demo_cart'][$i][2]);?></span>
            </li>
            <?php $total_value=$total_value+$_SESSION['demo_cart'][$i][2];?>
              <?php endif;?>
            <?php endfor;?>
            <li class="list-group-item d-flex justify-content-between">
              <span>Total (ZAR)</span>
              <strong><?php print_r($total_value);?></strong>
              <input type="hidden" id="cartTotal" value="<?php print_r($total_value)?>">
            </li>
          </ul>
          <!-- Cart -->
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->
       <?php elseif(isset($_GET['action']) && $_GET['action'] === "about"):?>
       <?php elseif(isset($_GET['action']) && $_GET['action'] === "contact"):?>
       <?php else:?>
      <!--Section: Products-->
      <section class="text-center mb-4">
        <?php
          $item_count;
          try {
            //code...
            $conn = DB::connectDB();
            $item_count = DB::initializeDemoItems($conn);
            //Get Searched Items
            if(isset($_POST['search'])) {
              $results = DB::getSearchedItems($conn,$_POST['search'],  session_id());
              if($results->num_rows === 0){
                echo '<h5 class="red-text"><strong>No results returned from search.</strong></h5>';
              }
            }
            //Get Items, if session is set, user is logged in
            if(isset($_SESSION['ID']) && !empty($_SESSION['ID'])){
                $results = DB::getItems_SI($conn,$_SESSION['ID']);              
            }elseif (!isset($results)){
              //else get demo items
                $results = DB::getItems($conn);
            }
            //Display no items returned message
          if($results->num_rows === 0 && !isset($_POST['search'])){
                  echo '<h5 class="red-text"><strong>Please upload shopping items in order to display items in item list.</strong></h5>';
          }?>
          <!-- Display items based on set result -->
          <div class="row wow fadeIn">
              <?php 
              while($row = $results->fetch_assoc()):?>
                      <!--Grid column-->
                      <div class="col-lg-3 col-md-6 mb-4">
                        <!--Card-->
                        <div class="card">
                          <!--Card image-->
                          <div class="view overlay">
                            <img src="<?php echo $row['item_img_src'];?>" class="card-img-top" alt="">
                            <a><div class="mask rgba-white-slight"></div></a>
                          </div>
                          <!--Card image-->
                          <!--Card content-->
                          <div class="card-body text-center">
                            <!--Category & Title-->
                            <a href="<?php echo WEB_HOST;?>/?action=viewItem&id=<?php echo $row['id'];?>" class="grey-text"><h5><?php echo $row['item_cat'];?></h5></a>
                            <h5>
                              <strong><a href="<?php echo WEB_HOST;?>/?action=viewItem&id=<?php echo $row['id'];?>" class="dark-grey-text"><?php echo $row['item_name'];?>
                                  <?php if($row['item_desc'] !== null): ?>
                                  <span class="badge badge-pill primary-color"><?php echo $row['item_desc'];?></span>
                                  <?php endif;?>
                                  </a>
                              </strong>
                            </h5>
                            <!-- Price -->
                            <h4 class="font-weight-bold blue-text">
                              <strong><?php echo 'R'.$row['item_price'];?></strong>
                            </h4>
                            <a class="action-button shadow animate blue" onclick="addToCart(<?php echo $row['id'];?>)"><span>Add To Cart</span></a>
                            <a class="action-button shadow animate red" onclick="deleteItem(<?php echo $row['id'];?>)"><span>Delete</span></a>
                          </div>
                          <!--Card content-->
                        </div>
                        <!--Card-->
                      </div>
                      <!--Grid column-->
                <?php endwhile;
              DB::closeConnection($conn);?></div>
          <?php }catch (\Throwable $th) {
            //throw $th;
            echo '<h5 class="red-text"><strong>'.$th->getMessage().'.</strong> Notification has been sent to administrators to resolve the issue, we apologies for the</h5>';
          }?>
          <h4 class="addToCartSuccess font-weight-bold green-text" style="display: none"> Item Added to Cart</h4>
          <h4 class="addToCartDelete font-weight-bold red-text" style="display: none"> Item Delete from Cart</h4>
      </section>
      <!--Section: Products-->
      <!--Pagination-->
          <nav class="d-flex justify-content-center wow fadeIn">
              <ul class="pagination pg-blue" style="display:none;">
              <!--Arrow left-->
                <li class="page-item disabled">
                  <a class="page-link" aria-label="Previous" onclick="changePagItem('prev')">
                    <span aria-hidden="true">&laquo;</span>
                    <span class="sr-only">Previous</span>
                  </a>
                </li>
                <li class="page-item active">
                  <a class="page-link">1
                    <span class="sr-only"></span>
                  </a>
                </li>
                <li class="page-item">
                    <a class="page-link"></a>
                </li>         
              <li class="page-item">
                <a class="page-link" aria-label="Next" onclick="changePagItem('next')">
                  <span aria-hidden="true">&raquo;</span>
                  <span class="sr-only">Next</span>
                </a>
              </li>
        </ul>
      </nav>
          <?php endif;?>
    </div>
  </main>
  <!--Main layout-->
  <!--Footer-->
  <footer class="page-footer text-center font-small mt-4 wow fadeIn">
    <!--Call to action-->
    <div class="pt-4">
      <a class="btn btn-outline-white" href="<?php echo WEB_HOST;?>/uploads/Item_list.xlsx" target="_blank"
        role="button">Download Sample Excel File
        <i class="fas fa-download ml-2"></i>
      </a>
    </div>
    <!--/.Call to action-->
    <hr class="my-4">
    <!-- Social icons -->
    <div class="pb-4">
      <a href="https://www.facebook.com/tthale34" target="_blank">
        <i class="fab fa-facebook-f mr-3"></i>
      </a>
    </div>
    <!-- Social icons -->
    <!--Copyright-->
    <div class="footer-copyright py-3">
      © 2020 Copyright:
      <a href=""> tthale.co.za </a>
    </div>
    <!--/.Copyright-->
  </footer>
  <!--/.Footer-->
  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Initializations -->
  <script type="text/javascript">
    // Animations initialization
    new WOW().init();
    
    loginType();
    function checkOutCart(){
      alert($('#cart').val());
    }
    function addToCart(item_id){
        $.ajax({
        url: "addToCart.php",
        type: "post",
        dataType: "json",
        data: {id:item_id},
        success: function(d) {			
                $('.addToCartSuccess').css("display","inline");
                $('.addToCartSuccess').append(d);
                $('.addToCartSuccess').delay(5000).fadeOut();
        },
        error: function (request, status, error) {
          if(error !== null){
            console.log("An error has occured:\n "+JSON.stringify(request) + "\n"+
                        JSON.stringify(status) + "\n" +
                        error);
          }if(error == "SyntaxError: Unexpected end of JSON input"){
              $('.addToCartSuccess').css("display","inline");
              $('.addToCartSuccess').delay(5000).fadeOut();
          }
        }});
    }
    function addToCartMulti(item_id){
        let number = $('#number_items').val();
        $.ajax({
        url: "addToCart.php",
        type: "post",
        dataType: "json",
        data: {id:item_id,number:number_items},
        success: function(d) {			
                $('.addToCartSuccess').css("display","inline");
                $('.addToCartSuccess').append(d);
                $('.addToCartSuccess').delay(5000).fadeOut();
        },
        error: function (request, status, error) {
          if(error !== null){
            console.log("An error has occured:\n "+JSON.stringify(request) + "\n"+
                        JSON.stringify(status) + "\n" +
                        error);
          }
          if(error == "SyntaxError: Unexpected end of JSON input"){
              $('.addToCartSuccess').css("display","inline");
              $('.addToCartSuccess').delay(5000).fadeOut();
          }
        }});
    }
    function deleteItem(item_id){
        $.ajax({
        url: "deleteItem.php",
        type: "post",
        dataType: "json",
        data: {id:item_id},
        success: function(d) {			
                $('.addToCartDelete').css("display","inline");
                $('.addToCartDelete').append(d);
                $('.addToCartDelete').delay(5000).fadeOut();
        },
        error: function (request, status, error) {
          if(error !== null){
            console.log("An error has occured:\n "+JSON.stringify(request) + "\n"+
                        JSON.stringify(status) + "\n" +
                        error);
          }
          if(error == "SyntaxError: Unexpected end of JSON input"){
              $('.addToCartDelete').css("display","inline");
              $('.addToCartDelete').delay(5000).fadeOut();
          }
        }
        });
    }
    function loginType(){
        if($("#loginType").val() === "Login"){
            $(".login").css("display","inline-block");
            $(".register").css("display","none");
        }else{
            $(".login").css("display","none");
            $(".register").css("display","inline-block");
        }
    }
    function checkPassword(){
        //alert($("#password").val().length);
        for(let i = 0; i < $("#password").val().length; i++){
            
        }
    }
    function checkPasswordMatch(){
        if($("#password").val() !== $("#conf_password").val()){
            alert("Passwords do not match, make sure password and confirm password are the same.");
            exit;
        }
        
    }
    function handleFiles(files){
        var formData = new FormData($('.EditUserInfo')[0]);
        $.ajax({
            url: 'insert_image',
            type: 'POST',
            dataType: 'json', 
            maxNumberOfFiles:1, 
            autoUpload: false, 
            xhr: function(){
                myXhr = $.ajaxSettings.xhr(); 
                if(myXhr.upload){
                    myXhr.upload.addEventListener('progress', progressHandlingFunction, false);
                }
                return myXhr;
            }, 
            success: function(result){
                console.log($.ajaxSettings.xhr().upload);
                alert('upload is done');
            }, 
            "error": function (x,y,z){
                alert("An error has occured:\n "+JSON.stringify(x) + "\n"+
                        JSON.stringify(y) + "\n" +
                        JSON.stringify(z));
             }, 
             data: formData,
             cache: false, 
             processData: false
        });
    }
  </script>
</body>
</html>