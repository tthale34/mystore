<?php
require 'config.php';
require 'DB.php';
session_start();
if (isset($_POST['id'])) {
    // Create connection
    $connection = DB::connectDB();
    $results = DB::getItem($connection,$_POST['id']);
    //Check number of items that need to be added
    if(isset($_POST['number'])){
        for ($i=0; $i < $_POST['number'] ; $i++) { 
            // Append session cart with added item.
            $count_items = count($_SESSION['demo_cart']);
            if(isset($_SESSION['demo_cart']) && $count_items > 0 ){
                $row = $results->fetch_assoc();
                $_SESSION['demo_cart'][$count_items+1] = [$row['item_name'],$row['id'],$row['item_price']]; 
            }
        }
    }  else {
        // Append session cart with added item.
        $count_items = count($_SESSION['demo_cart']);
        if(isset($_SESSION['demo_cart']) && $count_items > 0 ){
            $row = $results->fetch_assoc();
            $_SESSION['demo_cart'][$count_items+1] = [$row['item_name'],$row['id'],$row['item_price']]; 
        }
    }        
    //Close db connection 
    DB::closeConnection($connection);
    return json_encode($_SESSION['demo_cart']);
    
}