<?php
require 'config.php';
require 'DB.php';
session_start();
if (isset($_POST['paymentMethod'])) {

}